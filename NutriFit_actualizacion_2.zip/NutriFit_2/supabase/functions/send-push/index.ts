// ============================================================
// NutriFit — Edge Function "send-push"
// La llaman los Database Webhooks de Supabase cuando se inserta una fila en
// chat_messages (mensaje o receta por el chat) o en wall_posts (publicación
// en el Muro), y manda una notificación push a los móviles de los
// destinatarios. Envío Web Push estándar (VAPID + cifrado aes128gcm, RFC
// 8291/8292) hecho con Web Crypto, sin librerías externas de push.
// ============================================================
import { createClient } from "npm:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
const VAPID_PUBLIC_KEY = Deno.env.get("VAPID_PUBLIC_KEY") ?? "";
const VAPID_PRIVATE_KEY = Deno.env.get("VAPID_PRIVATE_KEY") ?? "";
const VAPID_SUBJECT = Deno.env.get("VAPID_SUBJECT") ?? "mailto:nutrifit@example.com";
const WEBHOOK_SECRET = Deno.env.get("WEBHOOK_SECRET") ?? "";

const db = createClient(SUPABASE_URL, SERVICE_KEY, { auth: { persistSession: false } });

// ---- WEBPUSH:START (sin dependencias: Web Crypto estándar) ----
const enc = new TextEncoder();
function b64uToBytes(s: string): Uint8Array {
  s = s.replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
function bytesToB64u(bytes: ArrayBuffer | Uint8Array): string {
  let bin = "";
  const b = new Uint8Array(bytes);
  for (let i = 0; i < b.length; i++) bin += String.fromCharCode(b[i]);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function concat(...parts: Uint8Array[]): Uint8Array {
  const len = parts.reduce((n, p) => n + p.length, 0);
  const out = new Uint8Array(len);
  let o = 0;
  for (const p of parts) { out.set(p, o); o += p.length; }
  return out;
}
async function hmac(key: Uint8Array, data: Uint8Array): Promise<Uint8Array> {
  const k = await crypto.subtle.importKey("raw", key as BufferSource, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return new Uint8Array(await crypto.subtle.sign("HMAC", k, data as BufferSource));
}
// Firma VAPID (JWT ES256) para el servicio de push del navegador.
async function vapidAuthHeader(endpoint: string, vapidPublicB64u: string, vapidPrivateB64u: string, subject: string): Promise<string> {
  const pub = b64uToBytes(vapidPublicB64u);
  const jwk = {
    kty: "EC", crv: "P-256", ext: true,
    d: vapidPrivateB64u,
    x: bytesToB64u(pub.slice(1, 33)),
    y: bytesToB64u(pub.slice(33, 65)),
  };
  const key = await crypto.subtle.importKey("jwk", jwk, { name: "ECDSA", namedCurve: "P-256" }, false, ["sign"]);
  const header = bytesToB64u(enc.encode(JSON.stringify({ typ: "JWT", alg: "ES256" })));
  const payload = bytesToB64u(enc.encode(JSON.stringify({
    aud: new URL(endpoint).origin,
    exp: Math.floor(Date.now() / 1000) + 12 * 3600,
    sub: subject,
  })));
  const unsigned = `${header}.${payload}`;
  const sig = new Uint8Array(await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, key, enc.encode(unsigned)));
  return `vapid t=${unsigned}.${bytesToB64u(sig)}, k=${vapidPublicB64u}`;
}
// Cifrado del contenido (RFC 8291, "aes128gcm"): solo el móvil destinatario
// puede leer el mensaje.
async function encryptPayload(p256dhB64u: string, authB64u: string, plaintext: string): Promise<Uint8Array> {
  const uaPublic = b64uToBytes(p256dhB64u);
  const authSecret = b64uToBytes(authB64u);
  const eph = await crypto.subtle.generateKey({ name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"]);
  const asPublic = new Uint8Array(await crypto.subtle.exportKey("raw", eph.publicKey));
  const uaKey = await crypto.subtle.importKey("raw", uaPublic as BufferSource, { name: "ECDH", namedCurve: "P-256" }, false, []);
  const ecdhSecret = new Uint8Array(await crypto.subtle.deriveBits({ name: "ECDH", public: uaKey }, eph.privateKey, 256));
  const prkKey = await hmac(authSecret, ecdhSecret);
  const ikm = await hmac(prkKey, concat(enc.encode("WebPush: info\0"), uaPublic, asPublic, new Uint8Array([1])));
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const prk = await hmac(salt, ikm);
  const cek = (await hmac(prk, concat(enc.encode("Content-Encoding: aes128gcm\0"), new Uint8Array([1])))).slice(0, 16);
  const nonce = (await hmac(prk, concat(enc.encode("Content-Encoding: nonce\0"), new Uint8Array([1])))).slice(0, 12);
  const aesKey = await crypto.subtle.importKey("raw", cek as BufferSource, { name: "AES-GCM" }, false, ["encrypt"]);
  const padded = concat(enc.encode(plaintext), new Uint8Array([2]));
  const cipher = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv: nonce as BufferSource }, aesKey, padded as BufferSource));
  const rs = new Uint8Array([0, 0, 16, 0]); // 4096
  return concat(salt, rs, new Uint8Array([asPublic.length]), asPublic, cipher);
}
async function sendWebPush(
  sub: { endpoint: string; p256dh: string; auth: string },
  payloadObj: unknown,
  vapid: { publicKey: string; privateKey: string; subject: string },
): Promise<Response> {
  const body = await encryptPayload(sub.p256dh, sub.auth, JSON.stringify(payloadObj));
  const authorization = await vapidAuthHeader(sub.endpoint, vapid.publicKey, vapid.privateKey, vapid.subject);
  return fetch(sub.endpoint, {
    method: "POST",
    headers: {
      "Authorization": authorization,
      "Content-Encoding": "aes128gcm",
      "Content-Type": "application/octet-stream",
      "TTL": "86400",
      "Urgency": "high",
    },
    body: body as BodyInit,
  });
}
// ---- WEBPUSH:END ----

function cut(s: string | null | undefined, n: number): string { s = (s || "").trim(); return s.length > n ? s.slice(0, n - 1) + "…" : s; }

async function usernameOf(id: string | null): Promise<string> {
  if (!id) return "alguien";
  const { data } = await db.from("profiles").select("username").eq("id", id).maybeSingle();
  return data?.username ?? "alguien";
}

// A quién avisar y qué decir, según la tabla que disparó el webhook.
// deno-lint-ignore no-explicit-any
async function buildNotification(table: string, rec: any) {
  if (table === "chat_messages") {
    const [{ data: members }, { data: chat }, sender] = await Promise.all([
      db.from("chat_members").select("profile_id").eq("chat_id", rec.chat_id),
      db.from("chats").select("is_group,name").eq("id", rec.chat_id).maybeSingle(),
      usernameOf(rec.sender_id),
    ]);
    const recipients = (members ?? []).map((m: { profile_id: string }) => m.profile_id).filter((id: string) => id !== rec.sender_id);
    const dishName = rec.dish_snapshot?.name ?? "Receta";
    const body = chat?.is_group
      ? (rec.dish_snapshot ? `@${sender} ha enviado una receta: ${dishName}` : `@${sender}: ${rec.body}`)
      : (rec.dish_snapshot ? `Te ha enviado una receta: ${dishName}` : rec.body);
    return {
      recipients,
      payload: {
        title: chat?.is_group ? (chat.name || "Grupo") : `@${sender}`,
        body: cut(body, 180),
        url: `./#chat=${rec.chat_id}`,
        tag: `chat-${rec.chat_id}`,
      },
    };
  }
  if (table === "wall_posts") {
    const [{ data: fr }, author] = await Promise.all([
      db.from("friendships").select("requester_id,addressee_id").eq("status", "accepted")
        .or(`requester_id.eq.${rec.user_id},addressee_id.eq.${rec.user_id}`),
      usernameOf(rec.user_id),
    ]);
    const recipients = (fr ?? []).map((f: { requester_id: string; addressee_id: string }) => (f.requester_id === rec.user_id ? f.addressee_id : f.requester_id));
    const name = rec.dish_snapshot?.name ?? "una receta";
    return {
      recipients,
      payload: {
        title: `@${author} ha publicado en el Muro`,
        body: cut(rec.caption ? `${name} — ${rec.caption}` : name, 180),
        url: "./#muro",
        tag: `muro-${rec.id}`,
      },
    };
  }
  return null;
}

// Llamadas desde la propia app (botón "Enviar notificación de prueba"): hace
// falta CORS porque la app vive en GitHub Pages.
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
function json(obj: unknown, status = 200): Response {
  return new Response(JSON.stringify(obj), { status, headers: { ...CORS, "Content-Type": "application/json" } });
}

type Sub = { id: string; endpoint: string; p256dh: string; auth: string };
// Envía a todas las suscripciones y devuelve el detalle (para poder ver qué
// responde Apple/Google si algo falla).
async function sendToSubs(subs: Sub[], payload: unknown) {
  const vapid = { publicKey: VAPID_PUBLIC_KEY, privateKey: VAPID_PRIVATE_KEY, subject: VAPID_SUBJECT };
  let sent = 0;
  const errors: { status: number; body: string; host: string }[] = [];
  await Promise.all(subs.map(async (s) => {
    const host = (() => { try { return new URL(s.endpoint).host; } catch { return "?"; } })();
    try {
      const res = await sendWebPush(s, payload, vapid);
      if (res.ok) { sent++; return; }
      const body = (await res.text()).slice(0, 300);
      errors.push({ status: res.status, body, host });
      console.error("push", res.status, host, body);
      if (res.status === 404 || res.status === 410) {
        await db.from("push_subscriptions").delete().eq("id", s.id); // el móvil ya no existe o quitó el permiso
      }
    } catch (e) {
      errors.push({ status: 0, body: String(e).slice(0, 300), host });
      console.error("push error", e);
    }
  }));
  return { sent, subscriptions: subs.length, errors };
}

// Prueba desde la app: el usuario con sesión se manda un aviso a sí mismo.
async function handleTest(req: Request): Promise<Response> {
  const token = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
  const { data: u, error } = await db.auth.getUser(token);
  if (error || !u?.user) return json({ error: "Sesión no válida" }, 401);
  const { data: prof } = await db.from("profiles").select("id").eq("auth_user_id", u.user.id).maybeSingle();
  if (!prof) return json({ error: "Perfil no encontrado" }, 404);
  const { data: subs } = await db.from("push_subscriptions").select("id,endpoint,p256dh,auth").eq("user_id", prof.id);
  // 5 segundos de margen para salir de la app o bloquear el móvil y ver el aviso.
  await new Promise((r) => setTimeout(r, 5000));
  const result = await sendToSubs(subs ?? [], {
    title: "NutriFit",
    body: "Notificación de prueba: ¡funciona!",
    url: "./",
    tag: "prueba",
  });
  return json(result);
}

function authorized(req: Request): boolean {
  const secret = req.headers.get("x-webhook-secret");
  if (WEBHOOK_SECRET && secret === WEBHOOK_SECRET) return true;
  const bearer = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
  return !!SERVICE_KEY && bearer === SERVICE_KEY;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ ok: true });
  if (!VAPID_PUBLIC_KEY || !VAPID_PRIVATE_KEY) return json({ error: "Faltan las claves VAPID en Secrets" }, 500);

  // deno-lint-ignore no-explicit-any
  let evt: any;
  try { evt = await req.json(); } catch { return json({ error: "JSON no válido" }, 400); }
  if (evt?.test === true) return handleTest(req);
  if (!authorized(req)) return json({ error: "No autorizado (WEBHOOK_SECRET no coincide)" }, 401);
  if (evt?.type !== "INSERT" || !evt.record) return json({ ignorado: true });

  const n = await buildNotification(evt.table, evt.record);
  if (!n || !n.recipients.length) return json({ sent: 0, motivo: "sin destinatarios" });

  const { data: subs } = await db.from("push_subscriptions").select("id,endpoint,p256dh,auth").in("user_id", n.recipients);
  const result = await sendToSubs(subs ?? [], n.payload);
  return json(result);
});
